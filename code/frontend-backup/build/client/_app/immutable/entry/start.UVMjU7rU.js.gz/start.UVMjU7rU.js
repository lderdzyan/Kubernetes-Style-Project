import{l as o,c as r}from"../chunks/B0Symvci.js";export{o as load_css,r as start};
